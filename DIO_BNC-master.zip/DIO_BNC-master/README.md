# DIO_BNC
DIO_BNC 8 channel isolated digital input/output EEM

## Design Files

Design files (schematics, PCB layouts, BOMs) can be found at [DIO_BNC/Releases](https://github.com/sinara-hw/DIO_BNC/releases).

## Wiki

More information can be found on the [wiki](https://github.com/sinara-hw/DIO_BNC/wiki).
